#!/usr/bin/env python3
"""Package existing RGBA images as a Photoshop-compatible layered PSD.

Usage: python psd_packager.py manifest.json [output.psd]

Manifest example (layers are ordered BOTTOM to TOP):
{
  "width": 2048, "height": 472, "dpi": 300,
  "output": "artwork.psd", "preview": "preview.png",
  "layers": [
    {"name": "背景", "path": "background.png", "x": 0, "y": 0},
    {"name": "蜂巢", "path": "honey.png", "x": 1100, "y": 300,
     "group": ["前景", "蜂蜜"], "visible": true, "opacity": 255}
  ]
}

Paths resolve relative to the manifest. Group strings may use '/' separators.
Layers assigned to the same group should be contiguous in painting order.
Groups must not recur in separate runs, since regrouping would change stacking.
No image extraction or modification is performed. PIL composites provided layers
only to supply the flattened PSD compatibility preview.
"""

import argparse
import io
import json
import struct
from pathlib import Path

from PIL import Image


def u16(n): return struct.pack('>H', n)
def i16(n): return struct.pack('>h', n)
def u32(n): return struct.pack('>I', n)
def i32(n): return struct.pack('>i', n)


def tagged(key, data):
    # Additional layer information: length excludes even padding.
    return b'8BIM' + key + u32(len(data)) + data + (b'\0' if len(data) % 2 else b'')


def name_data(name):
    # Legacy fallback is ASCII; Unicode Photoshop name is in the luni tag.
    fallback = name.encode('ascii', 'replace')[:255]
    pascal = bytes([len(fallback)]) + fallback
    pascal += bytes((-len(pascal)) % 4)
    utf16 = name.encode('utf-16be')
    return pascal + tagged(b'luni', u32(len(utf16) // 2) + utf16)


def layer_record(layer):
    name = layer['name']
    group_type = layer.get('section')
    if group_type is not None:
        x = y = w = h = 0
        channels = []
    else:
        im = layer['image']
        x, y = layer['x'], layer['y']
        w, h = im.size
        # Channel IDs: R/G/B/Transparency; data length includes compression word.
        channels = [(0, im.getchannel('R').tobytes()),
                    (1, im.getchannel('G').tobytes()),
                    (2, im.getchannel('B').tobytes()),
                    (-1, im.getchannel('A').tobytes())]
    record = i32(y) + i32(x) + i32(y+h) + i32(x+w) + u16(len(channels))
    for channel_id, data in channels:
        record += i16(channel_id) + u32(len(data) + 2)
    record += b'8BIM' + (b'pass' if group_type in (1, 2) else b'norm')
    record += bytes([layer.get('opacity', 255), 0,
                     0 if layer.get('visible', True) else 2, 0])
    extra = u32(0) + u32(0) + name_data(name)
    if group_type is not None:
        extra += tagged(b'lsct', u32(group_type))
    record += u32(len(extra)) + extra
    channel_bytes = b''.join(u16(0) + data for _, data in channels)
    return record, channel_bytes


def group_parts(raw):
    if raw is None:
        return ()
    if isinstance(raw, str):
        return tuple(p for p in raw.split('/') if p)
    return tuple(str(p) for p in raw)


def grouped_topdown(layers):
    """Emit PSD group start/end pseudo-layers without changing paint order."""
    result, active = [], ()
    finished = set()
    for layer in reversed(layers):
        path = layer['group']
        common = 0
        while common < min(len(active), len(path)) and active[common] == path[common]:
            common += 1
        for i in range(len(active), common, -1):
            result.append({'name': '</Layer group>', 'section': 3})
            finished.add(active[:i])
        for i in range(common, len(path)):
            prefix = path[:i+1]
            if prefix in finished:
                raise ValueError(f'Group {"/".join(prefix)!r} recurs in noncontiguous runs')
            result.append({'name': path[i], 'section': 1})
        result.append(layer)
        active = path
    for _ in active:
        result.append({'name': '</Layer group>', 'section': 3})
    return result


def resolution_resource(dpi):
    data = u32(round(dpi * 65536)) + u16(1) + u16(1)
    data += u32(round(dpi * 65536)) + u16(1) + u16(1)
    # Resource 1005 ResolutionInfo, empty Pascal name, already even padded.
    return b'8BIM' + u16(1005) + b'\0\0' + u32(len(data)) + data


def package(manifest_path, output_override=None):
    manifest_path = Path(manifest_path).resolve()
    spec = json.loads(manifest_path.read_text(encoding='utf-8'))
    base = manifest_path.parent
    width, height = int(spec['width']), int(spec['height'])
    if not (1 <= width <= 30000 and 1 <= height <= 30000):
        raise ValueError('PSD v1 dimensions must be 1..30000')
    layers = []
    for raw in spec['layers']:
        path = (base / raw['path']).resolve()
        with Image.open(path) as source:
            im = source.convert('RGBA')
        layer = dict(raw)
        layer.update(image=im, x=int(raw.get('x', 0)), y=int(raw.get('y', 0)),
                     group=group_parts(raw.get('group')))
        layer['opacity'] = int(raw.get('opacity', 255))
        if not 0 <= layer['opacity'] <= 255:
            raise ValueError('Layer opacity must be 0..255')
        layers.append(layer)
    records = grouped_topdown(layers)
    if not 1 <= len(records) <= 32767:
        raise ValueError('PSD requires 1..32767 records')

    # Composite the supplied PNGs exactly as Normal Photoshop layers.
    composite = Image.new('RGBA', (width, height), (0, 0, 0, 0))
    for layer in layers:
        if not layer.get('visible', True):
            continue
        im = layer['image']
        if layer['opacity'] != 255:
            im = im.copy()
            im.putalpha(im.getchannel('A').point(lambda a: round(a * layer['opacity'] / 255)))
        composite.alpha_composite(im, (layer['x'], layer['y']))

    record_buffers, channel_buffers = [], []
    for record in records:
        rec, data = layer_record(record)
        record_buffers.append(rec)
        channel_buffers.append(data)
    layer_info = i16(len(records)) + b''.join(record_buffers) + b''.join(channel_buffers)
    layer_info += bytes(len(layer_info) % 2)
    layer_mask = u32(len(layer_info)) + layer_info + u32(0)
    resources = resolution_resource(float(spec.get('dpi', 300)))
    output = Path(output_override) if output_override else base / spec.get('output', 'artwork.psd')
    output.parent.mkdir(parents=True, exist_ok=True)
    # The compatibility image is RGB on white; layer alpha remains untouched.
    merged = Image.new('RGB', (width, height), 'white')
    merged.paste(composite.convert('RGB'), mask=composite.getchannel('A'))
    with output.open('wb') as f:
        f.write(b'8BPS' + u16(1) + bytes(6) + u16(3) + u32(height) + u32(width) + u16(8) + u16(3))
        f.write(u32(0))
        f.write(u32(len(resources)) + resources)
        f.write(u32(len(layer_mask)) + layer_mask)
        f.write(u16(0))
        for channel in merged.split():
            f.write(channel.tobytes())
    preview = base / spec.get('preview', output.stem + '_preview.png')
    composite.save(preview, dpi=(float(spec.get('dpi', 300)),) * 2)
    result = {'psd': str(output.resolve()), 'preview': str(preview.resolve()),
              'width': width, 'height': height, 'pixel_layers': len(layers),
              'groups': sum(1 for r in records if r.get('section') == 1),
              'bytes': output.stat().st_size}
    print(json.dumps(result, ensure_ascii=False))
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('manifest')
    parser.add_argument('output', nargs='?')
    args = parser.parse_args()
    package(args.manifest, args.output)
